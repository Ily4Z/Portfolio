#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LIGNES 5
#define MAX_COLONNES 5
#define MIN_LIGNES 3
#define MIN_COLONNES 3
#define MAX_SAISIE 20
#define MAX_PSEUDO 50

#define RESET "\033[0m"
#define ROUGE "\033[31m"
#define BLEU "\033[34m"
#define VIOLET "\033[35m"
#define JAUNE "\033[0;33m"

int couleurJoueur1, couleurJoueur2; // Variables pour stocker les couleurs des joueurs
int vrai = 1; // Variable utilisée comme condition pour les boucles

// Fonction pour saisir un pseudo sans espace
void saisirPseudo(char *pseudo, int joueur) {
    int pseudoValide = 0; // Variable pour vérifier la validité du pseudo
    while (!pseudoValide) { // Boucle jusqu'à ce qu'un pseudo valide soit saisi
        printf("\nJoueur %d, entrez un pseudo : ", joueur); // Demande à l'utilisateur de saisir un pseudo
        
         if(fgets(pseudo, 50, stdin) == NULL){ // Lecture de la saisie de l'utilisateur
            printf("\n🚨 Erreur de lecture. Veuillez réessayer : "); // Message d'erreur en cas de problème de lecture
            continue; // Retourne au début de la boucle
        }
        
        // Supprimer le saut de ligne ajouté par fgets
        pseudo[strcspn(pseudo, "\n")] = '\0'; // Remplace le saut de ligne par un caractère nul

        int longueur = strlen(pseudo); // Obtient la longueur du pseudo
        int estVide = 1; // Variable pour vérifier si le pseudo est vide
        for (int i = 0; i < longueur; i++) { // Boucle pour vérifier chaque caractère du pseudo
            if (!isspace((unsigned char)pseudo[i])) { // Vérifie si le caractère n'est pas un espace
                estVide = 0; // Le pseudo n'est pas vide
                break; // Sort de la boucle
            }
        }
        
        // Vérifier s'il y a un espace dans le pseudo
         if (estVide) { // Si le pseudo est vide
            printf("\n🚨 Erreur: Le pseudo ne peut pas etre vide. Veuillez réessayer.\n"); // Message d'erreur
        } else if (strchr(pseudo, ' ') != NULL) { // Si le pseudo contient un espace
            printf("\n🚨 Erreur : Entrez un seul pseudo sans espace.\n"); // Message d'erreur
        } else {
            pseudoValide = 1; // Le pseudo est valide
        }
    }
}

// Fonction pour vérifier que les deux pseudos sont différents
void verifierPseudos(char *pseudo1, char *pseudo2, int joueur2) {
    while (strcmp(pseudo1, pseudo2) == 0) { // Tant que les pseudos sont identiques
        printf("\n🚨 Erreur : Les pseudos des deux joueurs doivent être différents.\n"); // Message d'erreur
        saisirPseudo(pseudo2, joueur2); // Demande à joueur 2 de saisir un nouveau pseudo
    }
}

int ChoixCouleur(const char* pseudoJoueur) {
    int couleur; // Variable pour stocker la couleur choisie
    char saisie[MAX_SAISIE];  // Pour capturer l'entrée complète sous forme de chaîne
    
    printf("\n%s, veuillez choisir une couleur 1 = 🟥, 2 = 🟦 : ", pseudoJoueur); // Demande de choix de couleur
    
    while (vrai) { // Boucle infinie pour continuer à demander jusqu'à ce qu'une entrée valide soit fournie
        // Lire l'entrée sous forme de chaîne de caractères
        fgets(saisie, sizeof(saisie), stdin);
        
        // Supprimer le saut de ligne éventuel ajouté par fgets
        saisie[strcspn(saisie, "\n")] = '\0';
        
        // Vérifier si l'entrée contient un seul nombre valide (1 ou 2)
        if (sscanf(saisie, "%d", &couleur) == 1 && (couleur == 1 || couleur == 2) && strchr(saisie, ' ') == NULL) {
            break;  // Si la couleur est valide et qu'il n'y a pas d'espace, on sort de la boucle
        } else {
            printf("\n🚨 Erreur : Saisie invalide, 1 pour Rouge, 2 pour Bleu : "); // Message d'erreur en cas de saisie invalide
        }
    }

    return couleur; // Retourne la couleur choisie
}

void ChoisirDimensions(int* L, int* C) {
    char saisie[MAX_SAISIE];  // Saisie pour lire l'entrée de l'utilisateur

    printf("\nEntrez les dimensions de votre plateau, uniquement 3 ou 5 pour les lignes et colonnes (exemple : 3 5) : "); // Demande de dimensions
    
    while (vrai) { // Boucle infinie pour continuer à demander jusqu'à ce qu'une entrée valide soit fournie
        // Lire l'entrée sous forme de chaîne de caractères
        if (fgets(saisie, sizeof(saisie), stdin) != NULL) {
            // Supprimer le saut de ligne éventuel ajouté par fgets
            saisie[strcspn(saisie, "\n")] = '\0';
            
            // Vérifier que l'entrée contient exactement deux entiers
            int entree = sscanf(saisie, "%d %d", L, C);
            
            // Si on a bien lu deux entiers
            if (entree == 2) {
                // Compter le nombre d'espaces dans l'entrée
                int espaces = 0;
                for (int i = 0; saisie[i] != '\0'; i++) {
                    if (saisie[i] == ' ') {
                        espaces++;
                    }
                }

                // Si il y a plus de 1 espace, cela signifie qu'il y a plus de deux valeurs
                if (espaces == 1) {
                    // Vérifier que les dimensions sont dans la plage et impaires
                    if (*L >= MIN_LIGNES && *L <= MAX_LIGNES && *L % 2 != 0 && *C >= MIN_COLONNES && *C <= MAX_COLONNES && *C % 2 != 0) {
                        break;  // Sortir de la boucle si les dimensions sont valides
                    } else {
                        printf("\n🚨 Erreur : Les dimensions doivent être %d ou %d pour les lignes, et %d ou %d pour les colonnes : ", MIN_LIGNES, MAX_LIGNES, MIN_COLONNES, MAX_COLONNES); // Message d'erreur pour dimensions invalides
                    }
                } else {
                    printf("\n🚨 Erreur : Entrez 2 dimensions avec un espace entre les deux : "); // Message d'erreur si le format est incorrect
                }
            } else {
                // Si l'on n'a pas bien lu deux entiers
                printf("\n🚨 Erreur : Entrez 2 dimensions avec un espace entre les deux : "); // Message d'erreur si le format est incorrect
            }
        }
    }
}

void AfficherPlateau(int plateau[MAX_LIGNES][MAX_COLONNES], int L, int C, int couleurJoueur1, int couleurJoueur2, int final) {
    // Affiche le plateau de jeu, soit l'état actuel, soit l'état final
    if (final) {
        printf("\n%s=== Plateau Final ===%s\n\n", VIOLET, RESET); // Affichage du message pour le plateau final
    } else {
        printf("\n%s=== Plateau Actuel ===%s\n\n", VIOLET, RESET); // Affichage du message pour le plateau actuel
    }

    printf("     "); // Espacement pour l'affichage des colonnes
    for (int j = 0; j < C; j++) {
        printf(" %s%2d%s  ", JAUNE, j + 1, RESET); // Affichage des numéros de colonnes
    }
    printf("\n");

    for (int i = 0; i < L; i++) {
        printf(" %s%d%s  ", JAUNE, i + 1, RESET); // Affichage des numéros de lignes
        for (int j = 0; j < C; j++) {
            if (plateau[i][j] > 0) {
                printf(" %s%3d%s ", couleurJoueur1 == 1 ? ROUGE : BLEU, plateau[i][j], RESET); // Affichage des jetons du joueur 1
            } else if (plateau[i][j] < 0) {
                printf(" %s%3d%s ", couleurJoueur2 == 1 ? ROUGE : BLEU, abs(plateau[i][j]), RESET); // Affichage des jetons du joueur 2
            } else {
                printf(" %3d ", plateau[i][j]); // Affichage des cases vides
            }
        }
        printf("\n"); // Nouvelle ligne après chaque ligne du plateau
    }
    printf("\n"); // Espacement après l'affichage du plateau
}

int CreerPlateau(int plateau[MAX_LIGNES][MAX_COLONNES], int L, int C) {
    // Initialise le plateau à zéro
    for (int i = 0; i < L; i++) {
        for (int j = 0; j < C; j++) {
            plateau[i][j] = 0; // Chaque case est initialisée à 0
        }
    }
    return 1; // Retourne 1 pour indiquer que le plateau a été créé avec succès
}

void initialiserJetons(int n, int *jetonsA, int *jetonsB) {
    // Initialise les jetons pour les deux joueurs
    for (int i = 0; i < n; i++) {
        jetonsA[i] = (i + 1); // Jetons positifs pour le joueur A
        jetonsB[i] = -(i + 1); // Jetons négatifs pour le joueur B
    }
}

void placerJeton(int plateau[MAX_LIGNES][MAX_COLONNES], const char* pseudoJoueur, int *L, int *C, int jeton, int couleur) {
    int x, y; // Variables pour stocker les coordonnées saisies
    char saisie[MAX_SAISIE];  // Saisie pour lire l'entrée de l'utilisateur

    printf("\n%s%s%s, entrez une position sous la forme (ligne colonne) : ", couleur == 1 ? ROUGE : BLEU, pseudoJoueur, RESET); // Demande de saisie de position

    while (vrai) { // Boucle infinie pour continuer à demander jusqu'à ce qu'une entrée valide soit fournie
        // Lire l'entrée sous forme de chaîne de caractères
        if (fgets(saisie, sizeof(saisie), stdin) != NULL) {
            // Vérifier que l'entrée contient exactement deux entiers
            int entree = sscanf(saisie, "%d %d", &x, &y);

            if (entree == 2) {
                // Compter le nombre d'espaces dans l'entrée
                int espaces = 0;
                for (int i = 0; saisie[i] != '\0'; i++) {
                    if (saisie[i] == ' ') {
                        espaces++;
                    }
                }

                // Si il y a un seul espace, cela signifie qu'il y a deux valeurs
                if (espaces == 1) {
                    // Ajuster les indices pour correspondre aux indices internes du tableau
                    x = x - 1; // Conversion de l'entrée utilisateur à l'index du tableau
                    y = y - 1; // Conversion de l'entrée utilisateur à l'index du tableau

                    // Vérification des erreurs spécifiques
                    if (x < 0 || x >= *L || y < 0 || y >= *C) {
                        printf("\n🚨 Erreur : Les coordonnées (%d, %d) sont hors du plateau. Veuillez entrer des valeurs entre 1 et %d pour x et entre 1 et %d pour y : \n", x + 1, y + 1, *L, *C); // Message d'erreur pour coordonnées hors limites
                    } else if (plateau[x][y] != 0) {
                        printf("\n🚨 Erreur : La case (%d, %d) est déjà occupée. Veuillez choisir une autre position : ", x + 1, y + 1); // Message d'erreur pour case occupée
                    } else {
                        // Les coordonnées sont valides et la case est libre
                        plateau[x][y] = jeton; // Placement du jeton sur le plateau
                        break; // Sortie de la boucle
                    }
                } else {
                    printf("\n🚨 Erreur : Vous avez saisi trop de valeurs. Entrez uniquement deux coordonnées séparées d'un seul espace : "); // Message d'erreur pour trop de valeurs
                }
            } else {
                // Réafficher le message avec la bonne couleur
                printf("\n🚨 Erreur : %s%s%s, entrez une position sous la forme (ligne colonne) : ", couleur == 1 ? ROUGE : BLEU, pseudoJoueur, RESET); // Message d'erreur pour format incorrect
            }
        }
    }
}

int calculerScores(int plateau[MAX_LIGNES][MAX_COLONNES], int L, int C, int joueur) {
    int score = 0; // Variable pour stocker le score
    int zeroX = -1, zeroY = -1; // Variables pour stocker les coordonnées de la case 0

    // Trouver la position de la case contenant 0
    for (int i = 0; i < L; i++) {
        for (int j = 0; j < C; j++) {
            if (plateau[i][j] == 0) {
                zeroX = i; // Stockage de la coordonnée x de la case 0
                zeroY = j; // Stockage de la coordonnée y de la case 0
                break; // Sortie de la boucle
            }
        }
        if (zeroX != -1) break; // Sortie de la boucle si la case 0 est trouvée
    }

    // Calculer le score en vérifiant les cases autour de la case 0
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue; // Ignorer la case centrale elle-même

            int x = zeroX + i; // Calcul de la coordonnée x de la case à vérifier
            int y = zeroY + j; // Calcul de la coordonnée y de la case à vérifier

            // Vérifier que les indices sont dans les limites du plateau
            if (x >= 0 && x < L && y >= 0 && y < C) {
                // Ajouter la valeur si elle appartient au joueur
                if ((joueur == 1 && plateau[x][y] > 0) || (joueur == 2 && plateau[x][y] < 0)) {
                    score += abs(plateau[x][y]); // Ajout de la valeur au score
                }
            }
        }
    }
    return score; // Retourne le score calculé
}


int main() {
    char rejouer; // Variable pour stocker la réponse de l'utilisateur
    char pseudoJoueur1[MAX_PSEUDO], pseudoJoueur2[MAX_PSEUDO]; // Variables pour stocker les pseudos des joueurs

    // Saisie des pseudos des joueurs
    saisirPseudo(pseudoJoueur1, 1);
    saisirPseudo(pseudoJoueur2, 2);

    // Vérification que les pseudos sont différents
    verifierPseudos(pseudoJoueur1, pseudoJoueur2, 2);

    // Choix des couleurs
    couleurJoueur1 = ChoixCouleur(pseudoJoueur1);
    couleurJoueur2 = (couleurJoueur1 == 1) ? 2 : 1;

    do {
        int L, C; // Variables pour stocker les dimensions du plateau

        // Affichage des couleurs choisies
        printf("\n%s a choisi la couleur %s%s%s, %s aura donc la couleur %s%s%s.\n", pseudoJoueur1, (couleurJoueur1 == 1 ? ROUGE : BLEU), (couleurJoueur1 == 1 ? "Rouge" : "Bleu"), RESET, pseudoJoueur2, (couleurJoueur2 == 1 ? ROUGE : BLEU), (couleurJoueur2 == 1 ? "Rouge" : "Bleu"), RESET);

        // Saisie des dimensions du plateau
        ChoisirDimensions(&L, &C);

        // Création du plateau
        int plateau[MAX_LIGNES][MAX_COLONNES];
        CreerPlateau(plateau, L, C);

        // Affichage du plateau
        AfficherPlateau(plateau, L, C, couleurJoueur1, couleurJoueur2, 0);

        // Initialisation des jetons
        int nombreJetons = (L * C - 1) / 2;
        int jetonsA[nombreJetons], jetonsB[nombreJetons];
        initialiserJetons(nombreJetons, jetonsA, jetonsB);

        // Placement des jetons
        for (int i = 0; i < nombreJetons; i++) {
            placerJeton(plateau, pseudoJoueur1, &L, &C, jetonsA[i], couleurJoueur1);
            AfficherPlateau(plateau, L, C, couleurJoueur1, couleurJoueur2, 0);

            placerJeton(plateau, pseudoJoueur2, &L, &C, jetonsB[i], couleurJoueur2);
            AfficherPlateau(plateau, L, C, couleurJoueur1, couleurJoueur2, 0);
        }

        // Calcul des scores
        int scoreA = calculerScores(plateau, L, C, 1);
        int scoreB = calculerScores(plateau, L, C, 2);

        // Affichage des scores
        if (scoreA < scoreB) {
            printf("\n%s%s%s a gagné ! 🎉\n", couleurJoueur1 == 1 ? ROUGE : BLEU, pseudoJoueur1, RESET);
        } else if (scoreB < scoreA) {
            printf("\n%s%s%s a gagné ! 🎉\n", couleurJoueur2 == 1 ? ROUGE : BLEU, pseudoJoueur2, RESET);
        } else {
            printf("\nMatch nul...😐\n");
        }

        printf("\nLe score de %s%s%s est : %d\n", couleurJoueur1 == 1 ? ROUGE : BLEU, pseudoJoueur1, RESET, scoreA);
        printf("\nLe score de %s%s%s est : %d\n", couleurJoueur2 == 1 ? ROUGE : BLEU, pseudoJoueur2, RESET, scoreB);

        // Affichage du plateau final
        AfficherPlateau(plateau, L, C, couleurJoueur1, couleurJoueur2, 1);

        // Demande de rejouer
        printf("\nVoulez-vous rejouer ? o = OUI, n = NON : ");

        while (vrai) {
            scanf(" %c", &rejouer);

            if (rejouer == 'o' || rejouer == 'n') {
                while (getchar() != '\n');
                break;
            }

            while (getchar() != '\n');
            printf("\n🚨 Erreur : o pour OUI ou n pour NON : ");
        }

        if (rejouer == 'o') {
            char changerCouleur;
            printf("\nSouhaitez-vous changer la couleur des pseudos ? o = OUI, n = NON : ");

            while (vrai) {
                scanf(" %c", &changerCouleur);

                if (changerCouleur == 'o' || changerCouleur == 'n') {
                    while (getchar() != '\n');
                    break;
                }

                while (getchar() != '\n');
                printf("\n🚨 Erreur : o pour OUI ou n pour NON : ");
            }

            if (changerCouleur == 'o') {
                couleurJoueur1 = ChoixCouleur(pseudoJoueur1);
                couleurJoueur2 = (couleurJoueur1 == 1) ? 2 : 1;
            }
        }

    } while (rejouer == 'o');

    // Message de fin
    printf("\nBien joué %s%s%s et %s%s%s ! 😁 A la prochaine ! 👋\n\n", couleurJoueur1 == 1 ? ROUGE : BLEU, pseudoJoueur1, RESET, couleurJoueur2 == 1 ? ROUGE : BLEU, pseudoJoueur2, RESET);
    return 0;
}