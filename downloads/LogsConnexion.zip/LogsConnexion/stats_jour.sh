#!/bin/bash

if [[ $# -lt 2 || $# -gt 3 ]]; then
    echo "Usage : $0 <nom_utilisateur> <date (JJ-MM-AAAA)>"
    exit 1
fi

Nom_User="$1"
Date_co="$2"
OUTPUT_FILE="$3"

LOG_FILE="connexion.log"

if [[ ! -f "$LOG_FILE" ]]; then
    echo "Erreur : Le fichier $LOG_FILE n'existe pas."
    exit 1
fi

output_result() {
    local result="$1"
    if [[ -z "$OUTPUT_FILE" ]]; then
        echo -e "$result"
    else
        echo -e "$result" >> "$OUTPUT_FILE"
    fi
}

FILTERED_LOGS=$(grep ";$Nom_User;.*;$Date_co" "$LOG_FILE")

if [[ -z "$FILTERED_LOGS" ]]; then
    echo "Aucune donnée trouvée pour l'utilisateur '$Nom_User' à la date '$Date_co'."
    exit 0
fi

while true; do
    echo "Menu des statistiques pour $Nom_User le $Date_co"
    echo "1. Nombre de connexions par heure"
    echo "2. Machines différentes utilisées"
    echo "3. Adresses IP différentes utilisées"
    echo "4. Quitter"
    read -rp "Choisissez une option de 1 à 4 : " choice

    case $choice in
        1)
            result=$(echo "$FILTERED_LOGS" | awk -F';' '{split($4, datetime, " "); split(datetime[2], time, ":"); print time[1]}' | sort | uniq -c | awk '{print $2 "h: " $1 " connexions"}')
            output_result "Statistiques des connexions par heure :\n$result"
            ;;
        2)
            machines=$(echo "$FILTERED_LOGS" | awk -F';' '{print $3}' | sort | uniq)
            count=$(echo "$machines" | wc -l)
            result="Machines utilisées ($count) :\n$machines"
            output_result "$result"
            ;;
        3)
            ips=$(echo "$FILTERED_LOGS" | awk -F';' '{print $1}' | sort | uniq)
            count=$(echo "$ips" | wc -l)
            result="Adresses IP utilisées ($count) :\n$ips"
            output_result "$result"
            ;;
        4)
            echo "Au revoir !"
            exit 0
            ;;
        *)
            echo "Option invalide. Veuillez choisir entre 1 et 4."
            ;;
    esac
done