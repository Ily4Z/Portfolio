#!/bin/bash

LOG_FILE="connexion.log"

Adresse_ip=$(hostname -I | awk '{print $1}')
Nom_User=$(whoami)
nom_host=$(hostname)
Date_co=$(date "+%d-%m-%Y %H:%M:%S")

Log="$Adresse_ip;$Nom_User;$nom_host;$Date_co"

echo "$Log" >> $LOG_FILE

echo "$Log"