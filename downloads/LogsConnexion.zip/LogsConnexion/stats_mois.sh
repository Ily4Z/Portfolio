#!/bin/bash

# Vérification des paramètres
if [[ $# -ne 3 ]]; then
    echo "Usage : $0 <nom_utilisateur> <mois (MM-AAAA)> <0 (écran) | 1 (fichier)>"
    exit 1
fi

# Paramètres
Nom_User="$1"
Mois="$2"
Output_Mode="$3"
LOG_FILE="connexion.log"

# Vérification du format du mois
if ! [[ $Mois =~ ^[0-9]{2}-[0-9]{4}$ ]]; then
    echo "Erreur : Le format du mois doit être MM-AAAA."
    exit 1
fi

# Vérification du mode d'affichage
if [[ "$Output_Mode" -ne 0 && "$Output_Mode" -ne 1 ]]; then
    echo "Erreur : Le troisième paramètre doit être 0 (affichage écran) ou 1 (fichier)."
    exit 1
fi

# Vérification si le fichier de log existe
if [[ ! -f "$LOG_FILE" ]]; then
    echo "Erreur : Le fichier $LOG_FILE n'existe pas."
    exit 1
fi

# Extraction de l'année et du mois
Num_Mois=$(echo "$Mois" | cut -d'-' -f1)
Annee=$(echo "$Mois" | cut -d'-' -f2)

# Définir le dossier et le fichier de sortie si Output_Mode=1
if [[ "$Output_Mode" -eq 1 ]]; then
    OUTPUT_DIR="${Nom_User}_${Annee}"
    mkdir -p "$OUTPUT_DIR" || { echo "Erreur : Impossible de créer le répertoire $OUTPUT_DIR."; exit 1; }

    OUTPUT_FILE="${OUTPUT_DIR}/${Nom_User}_${Num_Mois}.log"
    > "$OUTPUT_FILE" || { echo "Erreur : Impossible de créer le fichier $OUTPUT_FILE."; exit 1; }
    echo "Fichier $OUTPUT_FILE créé."
fi

# Fonction pour afficher ou écrire le résultat
output_result() {
    local result="$1"
    if [[ "$Output_Mode" -eq 0 ]]; then
        echo -e "$result"
    else
        echo -e "$result" >> "$OUTPUT_FILE"
    fi
}

# Filtrer les logs pour l'utilisateur et le mois
FILTERED_LOGS=$(grep ";$Nom_User;.*;[0-9]\{2\}-$Mois" "$LOG_FILE")

if [[ -z "$FILTERED_LOGS" ]]; then
    output_result "Aucune donnée trouvée pour l'utilisateur '$Nom_User' durant le mois '$Mois'."
    exit 0
fi

# Calculs des statistiques
calcul_statistiques() {
    # 1. Nombre total de connexions
    total_connexions=$(echo "$FILTERED_LOGS" | wc -l)
    result_total_connexions="Nombre total de connexions pour $Nom_User durant $Mois : $total_connexions"
    output_result "$result_total_connexions"

    # 2. Nombre de connexions par jour
    connexions_par_jour=$(echo "$FILTERED_LOGS" | awk -F';' '{split($4, datetime, " "); split(datetime[1], date, "-"); print date[1]}' | sort | uniq -c | awk '{print "Jour " $2 ": " $1 " connexions"}')
    result_connexions_par_jour="Nombre de connexions par jour pour $Nom_User durant $Mois :\n$connexions_par_jour"
    output_result "$result_connexions_par_jour"

    # 3. Machines différentes utilisées
    machines=$(echo "$FILTERED_LOGS" | awk -F';' '{print $3}' | sort | uniq)
    count_machines=$(echo "$machines" | wc -l)
    result_machines="Machines utilisées ($count_machines) durant $Mois :\n$machines"
    output_result "$result_machines"

    # 4. Adresses IP différentes utilisées
    ips=$(echo "$FILTERED_LOGS" | awk -F';' '{print $1}' | sort | uniq)
    count_ips=$(echo "$ips" | wc -l)
    result_ips="Adresses IP utilisées ($count_ips) durant $Mois :\n$ips"
    output_result "$result_ips"
}

# Si le mode est "1", calculer directement toutes les statistiques dans un fichier
if [[ "$Output_Mode" -eq 1 ]]; then
    calcul_statistiques
    exit 0
fi

# Si le mode est "0", afficher le menu
while true; do
    echo "Menu des statistiques pour $Nom_User durant le mois $Mois"
    echo "1. Nombre total de connexions"
    echo "2. Nombre de connexions par jour"
    echo "3. Machines différentes utilisées"
    echo "4. Adresses IP différentes utilisées"
    echo "5. Quitter"
    read -rp "Choisissez une option de 1 à 5 : " choice

    case $choice in
        1)
            # Nombre total de connexions
            total_connexions=$(echo "$FILTERED_LOGS" | wc -l)
            result="Nombre total de connexions pour $Nom_User durant $Mois : $total_connexions"
            output_result "$result"
            ;;
        2)
            # Nombre de connexions par jour
            connexions_par_jour=$(echo "$FILTERED_LOGS" | awk -F';' '{split($4, datetime, " "); split(datetime[1], date, "-"); print date[1]}' | sort | uniq -c | awk '{print "Jour " $2 ": " $1 " connexions"}')
            result="Nombre de connexions par jour pour $Nom_User durant $Mois :\n$connexions_par_jour"
            output_result "$result"
            ;;
        3)
            # Machines différentes utilisées
            machines=$(echo "$FILTERED_LOGS" | awk -F';' '{print $3}' | sort | uniq)
            count_machines=$(echo "$machines" | wc -l)
            result="Machines utilisées ($count_machines) durant $Mois :\n$machines"
            output_result "$result"
            ;;
        4)
            # Adresses IP différentes utilisées
            ips=$(echo "$FILTERED_LOGS" | awk -F';' '{print $1}' | sort | uniq)
            count_ips=$(echo "$ips" | wc -l)
            result="Adresses IP utilisées ($count_ips) durant $Mois :\n$ips"
            output_result "$result"
            ;;
        5)
            echo "Au revoir !"
            exit 0
            ;;
        *)
            echo "Option invalide. Veuillez choisir entre 1 et 5."
            ;;
    esac
done
