#!/bin/bash

# Vérification des paramètres
if [[ $# -ne 2 ]]; then
    echo "Usage : $0 <mois (MM-AAAA)> <0 (écran) | 1 (fichier)>"
    exit 1
fi

# Paramètres
Mois="$1"
Affichage="$2"
LOG_FILE="connexion.log"

# Vérification si le fichier de log existe
if [[ ! -f "$LOG_FILE" ]]; then
    echo "Erreur : Le fichier $LOG_FILE n'existe pas."
    exit 1
fi

# Définir le répertoire de sortie si nécessaire
if [[ "$Affichage" -eq 1 ]]; then
    Annee=$(echo "$Mois" | cut -d'-' -f2)
    REPERTOIRE="$Annee"
    mkdir -p "$REPERTOIRE"
    FICHIER_SORTIE="${REPERTOIRE}/${Mois%%-*}.log"
    > "$FICHIER_SORTIE" || { echo "Erreur : Impossible de créer le fichier $FICHIER_SORTIE."; exit 1; }
    echo "Fichier $FICHIER_SORTIE créé."
fi

# Fonction pour afficher ou écrire le résultat
output_result() {
    local result="$1"
    if [[ "$Affichage" -eq 0 ]]; then
        echo -e "$result"
    else
        echo -e "$result" >> "$FICHIER_SORTIE"
    fi
}

# Extraire les lignes correspondant au mois spécifié
FILTERED_LOGS=$(grep ";.*;.*;[0-9]\{2\}-$Mois" "$LOG_FILE")

# Vérifier si des données existent
if [[ -z "$FILTERED_LOGS" ]]; then
    output_result "Aucune donnée trouvée pour le mois '$Mois'."
    exit 0
fi

# Calculs des statistiques
calcul_statistiques() {
    # 1. Nombre total de connexions
    total_connexions=$(echo "$FILTERED_LOGS" | wc -l)
    result_total_connexions="Nombre total de connexions pour le mois $Mois : $total_connexions"
    output_result "$result_total_connexions"

    # 2. Nombre de connexions par utilisateur
    result_par_utilisateur=$(echo "$FILTERED_LOGS" | awk -F';' '{print $2}' | sort | uniq -c | awk '{print $2 ": " $1 " connexions"}')
    output_result "Nombre de connexions par utilisateur :\n$result_par_utilisateur"

    # 3. Nombre de connexions par jour
    result_par_jour=$(echo "$FILTERED_LOGS" | awk -F';' '{split($4, datetime, " "); print datetime[1]}' | sort | uniq -c | awk '{print $2 ": " $1 " connexions"}')
    output_result "Nombre de connexions par jour :\n$result_par_jour"

    # 4. Nombre de machines différentes utilisées
    machines=$(echo "$FILTERED_LOGS" | awk -F';' '{print $3}' | sort | uniq)
    count_machines=$(echo "$machines" | wc -l)
    output_result "Machines utilisées ($count_machines) :\n$machines"
}

# Si le mode est "1", calculer directement toutes les statistiques dans un fichier
if [[ "$Affichage" -eq 1 ]]; then
    calcul_statistiques
    exit 0
fi

# Si le mode est "0", afficher le menu
while true; do
    echo "Menu des statistiques pour le mois $Mois"
    echo "1. Calcul du nombre de connexions au cours du mois"
    echo "2. Nombre de connexions par utilisateur au cours du mois"
    echo "3. Nombre de connexions par jour pour le mois"
    echo "4. Machines différentes utilisées au cours du mois"
    echo "5. Quitter"
    read -rp "Choisissez une option de 1 à 5 : " choice

    case $choice in
        1)
            # Calcul du nombre total de connexions
            total_connexions=$(echo "$FILTERED_LOGS" | wc -l)
            output_result "Nombre total de connexions pour le mois $Mois : $total_connexions"
            ;;
        2)
            # Nombre de connexions par utilisateur
            result=$(echo "$FILTERED_LOGS" | awk -F';' '{print $2}' | sort | uniq -c | awk '{print $2 ": " $1 " connexions"}')
            output_result "Nombre de connexions par utilisateur :\n$result"
            ;;
        3)
            # Nombre de connexions par jour
            result=$(echo "$FILTERED_LOGS" | awk -F';' '{split($4, datetime, " "); print datetime[1]}' | sort | uniq -c | awk '{print $2 ": " $1 " connexions"}')
            output_result "Nombre de connexions par jour :\n$result"
            ;;
        4)
            # Nombre de machines différentes utilisées
            machines=$(echo "$FILTERED_LOGS" | awk -F';' '{print $3}' | sort | uniq)
            count=$(echo "$machines" | wc -l)
            output_result "Machines utilisées ($count) :\n$machines"
            ;;
        5)
            echo "Au revoir !"
            exit 0
            ;;
        *)
            echo "Option invalide. Veuillez choisir entre 1 et 5."
            ;;
    esac
done
