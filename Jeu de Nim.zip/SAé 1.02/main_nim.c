#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include "nim.h"
#include "affichage.h"
#include "voisines.h"
#include "coup.h"
#include "utilitaires.h"
#include "parametres.h"
#include "stdbool.h"

#define MAX_PSEUDO 50

// Fonction pour vider le buffer d'entrée
void vider_buffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// Fonction pour vérifier si un pseudo est conforme
int pseudo_valide(const char *pseudo) {
    if (strlen(pseudo) == 0 || strlen(pseudo) >= MAX_PSEUDO) {
        return 0;
    }
}

int main() {
    srand(time(NULL));
    char pseudo[MAX_PSEUDO];
    int rejouer = 1;

    // Saisie et validation du pseudo
    while (1) {
        printf("Entrez votre pseudo (max %d caractères alphanumériques) : ", MAX_PSEUDO - 1);
        if (fgets(pseudo, MAX_PSEUDO, stdin) == NULL) {
            printf("Erreur lors de la saisie. Veuillez réessayer.\n");
            continue;
        }

        // Vérifie si l'utilisateur a dépassé la limite de saisie
        if (pseudo[strlen(pseudo) - 1] != '\n') {
            printf("Votre pseudo est trop long. Veuillez entrer au maximum %d caractères.\n", MAX_PSEUDO - 1);
            vider_buffer(); // Vider le buffer pour éviter des comportements inattendus
            continue;
        }

        // Supprime le caractère '\n' à la fin
        pseudo[strcspn(pseudo, "\n")] = '\0';

        if (pseudo_valide(pseudo)) {
            break; // Le pseudo est valide, on sort de la boucle
        } else {
            printf("Pseudo invalide ! Assurez-vous qu'il soit alphanumérique et qu'il ne dépasse pas %d caractères.\n", MAX_PSEUDO - 1);
        }
    }

    printf("Bienvenue, %s !\n", pseudo);

    while (rejouer) {
        T_Case pion = {0, 0};
        int nlig, ncol, niveau, premier;

        // Choix des paramètres
        do {
            printf("Choisissez le nombre de lignes (%d-%d): ", VMIN, VMAX);
            scanf("%d", &nlig);
            if (nlig < VMIN || nlig > VMAX) {
                printf("Nombre de lignes invalide. Veuillez réessayer.\n");
            }
        } while (nlig < VMIN || nlig > VMAX);

        do {
            printf("Choisissez le nombre de colonnes (%d-%d): ", VMIN, VMAX);
            scanf("%d", &ncol);
            if (ncol < VMIN || ncol > VMAX) {
                printf("Nombre de colonnes invalide. Veuillez réessayer.\n");
            }
        } while (ncol < VMIN || ncol > VMAX);

        do {
            printf("Choisissez le niveau de difficulté (%d = Facile, %d = Moyen, %d = Difficile, %d = Expert): ",
                   easy, medium, hard, expert);
            scanf("%d", &niveau);
            if (niveau < easy || niveau > expert) {
                printf("Niveau invalide. Veuillez réessayer.\n");
            }
        } while (niveau < easy || niveau > expert);

        do {
            printf("Qui commence ? (1 = %s, 2 = Ordinateur) : ", pseudo);
            scanf("%d", &premier);
            if (premier < 1 || premier > 2) {
                printf("Choix invalide. Veuillez entrer 1 ou 2.\n");
            }
        } while (premier < 1 || premier > 2);

        // Boucle de jeu
        bool joueur_gagne = false, ordinateur_gagne = false;
        while (!joueur_gagne && !ordinateur_gagne) {
            afficher_plateau(pion, nlig, ncol);

            if (premier == 1) {
                printf("C'est votre tour, %s !\n", pseudo);
                T_Case nouveau_pion = coup_joueur(&pion, nlig, ncol);

                if (nouveau_pion.ligne >= nlig || nouveau_pion.colonne >= ncol) {
                    printf("Déplacement invalide, essayez encore.\n");
                    continue;
                }
                pion = nouveau_pion;

                if (pion.ligne == nlig - 1 && pion.colonne == ncol - 1) {
                    joueur_gagne = true;
                    break;
                }

                premier = 2;
            } else {
                printf("Tour de l'ordinateur...\n");
                pion = coup_ordi(&pion, nlig, ncol, niveau);
                printf("L'ordinateur a déplacé le pion en (%d, %d).\n", pion.ligne + 1, pion.colonne + 1);

                if (pion.ligne == nlig - 1 && pion.colonne == ncol - 1) {
                    ordinateur_gagne = true;
                    break;
                }

                premier = 1;
            }
        }

        afficher_plateau(pion, nlig, ncol);
        if (joueur_gagne) {
            printf("Félicitations, %s, vous avez gagné !\n", pseudo);
        } else {
            printf("L'ordinateur a gagné. Bonne chance la prochaine fois, %s !\n", pseudo);
        }

        // Rejouer
        printf("Voulez-vous rejouer ? (1 = Oui, 0 = Non) : ");
        scanf("%d", &rejouer);
        vider_buffer(); // Nettoyer le buffer pour la prochaine saisie
    }

    printf("Merci d'avoir joué, %s. À bientôt !\n", pseudo);
    return 0;
}
