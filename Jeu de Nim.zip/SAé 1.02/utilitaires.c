#include <stdio.h>
#include <stdlib.h>
#include "nim.h"
#include "utilitaires.h"

int hasard(int min, int max){
    return (rand() % (max - min + 1)) + min; //appeler srand avec time dans le main
}