#ifndef VOISINES_H
#define VOISINES_H

#include "nim.h"

int voisines(T_Case pion, int nlig, int ncol, T_Tab_Case *vois); //mettre dans nim.h

#endif