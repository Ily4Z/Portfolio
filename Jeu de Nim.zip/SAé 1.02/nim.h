#ifndef NIM_H
#define NIM_H

#define VMIN 5
#define VMAX 30

#define easy 1
#define medium 2
#define hard 3
#define expert 4

// Définition des types

typedef struct {
    int ligne;
    int colonne;
} T_Case;

typedef struct {
    T_Case voisins[4]; // Nombre max de voisines
    int nb_vois;       // Nombre effectif de voisines
} T_Tab_Case;

//définition de la fonction nimber avec un INT -> 0 ou 1

int nimber(int ligne, int colonne, int nlig, int ncol);

#endif
