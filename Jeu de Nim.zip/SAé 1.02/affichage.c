#include <stdio.h>
#include <stdlib.h>
#include "nim.h"
#include "affichage.h"

// Afficher le plateau avec numérotation des lignes et des colonnes
void afficher_plateau(T_Case pion, int nlig, int ncol) {
    // Afficher les numéros de colonnes
    printf("    ");
    for (int j = 0; j < ncol; j++) {
        printf(" %d  ", j);
    }
    printf("\n");

    // Afficher les lignes du plateau
    for (int i = 0; i < nlig; i++) {
        printf(" %d  ", i);

        for (int j = 0; j < ncol; j++) {
            if (i == pion.ligne && j == pion.colonne) {
                printf(" | P");
            } else if (i == nlig - 1 && j == ncol - 1) {
                printf(" | X");
            } else {
                printf(" | -");
            }
        }
        printf("\n");
    }
    printf("\n");
}
