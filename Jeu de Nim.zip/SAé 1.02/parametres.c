#include <stdio.h>
#include <stdlib.h>
#include "nim.h"
#include "parametres.h"

// Lire un entier
int lire_entier(int min, int max) {
    int valeur;
    do {
        printf("Entrez un entier entre %d et %d : ", min, max);
        scanf("%d", &valeur);
    } while (valeur < min || valeur > max);
    return valeur;
}

// Définition de tous les paramètres par le joueur
void parametres(int *nlig, int *ncol, int *niveau, int *suivant) {
    printf("Paramètres du jeu :\n");
    *nlig = lire_entier(VMIN, VMAX);
    *ncol = lire_entier(VMIN, VMAX);
    *niveau = lire_entier(1, 4);
    printf("Qui commence ? (1 : Ordinateur, 2 : Joueur) : ");
    *suivant = lire_entier(1, 2);
}