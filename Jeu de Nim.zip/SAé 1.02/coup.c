#include <stdio.h>
#include <stdlib.h>
#include "nim.h"
#include "coup.h"

T_Case coup_ordi_hasard(T_Case *pion, T_Tab_Case *position, int nb_voisines, int nlig, int ncol) {
    int distance, destination;
    
    do {
        destination = hasard(1, 2); 

        distance = hasard(1, 2);  

        if (destination == 1 && pion->colonne + distance < ncol) {
            pion->colonne += distance;
            break;
        } else if (destination == 2 && pion->ligne + distance < nlig) {
            pion->ligne += distance;
            break;  
        }
    } while (1);  

return *pion;
}

T_Case coup_ordi_gagnant(T_Case *pion, int nlig, int ncol) {
    T_Tab_Case voisins;
    int nb_voisines = voisines(*pion, nlig, ncol, &voisins);

    printf("Test Coup Ordi Gagnant: Pion initial en (%d, %d)\n", pion->ligne, pion->colonne);

    for (int i = 0; i < nb_voisines; i++) {
        T_Case test = voisins.voisins[i];
        int vnimber = nimber(test.ligne, test.colonne, nlig, ncol);

        printf("  Voisin %d: (%d, %d), Nimber: %d\n", i + 1, test.ligne, test.colonne, vnimber);

        if (vnimber == 0) {
            *pion = test;
            printf("  Coup gagnant trouvé: (%d, %d)\n", test.ligne, test.colonne);
            return *pion;
        }
    }

    printf("Aucun coup gagnant trouvé. Utilisation de coup_ordi_hasard.\n");
    return coup_ordi_hasard(pion, &voisins, nb_voisines, nlig, ncol);
}



T_Case coup_ordi(T_Case *pion, int nlig, int ncol, int niveau) {
    int chance = 0;
    T_Tab_Case case_voisin;
    int nb_voisines = voisines(*pion, nlig, ncol, &case_voisin);

    switch (niveau) {
    case easy:
        coup_ordi_hasard(pion, &case_voisin, nb_voisines, nlig, ncol);
        break;

    case medium:
        chance = hasard(1, 10);
        if (chance < 1/3) {
            coup_ordi_hasard(pion, &case_voisin, nb_voisines, nlig, ncol);
        } else {
            coup_ordi_gagnant(pion, nlig, ncol);
        }
        break;

    case hard:
        chance = hasard(1, 10);
        if (chance > 1/3) {
            coup_ordi_hasard(pion, &case_voisin, nb_voisines, nlig, ncol);
        } else {
            coup_ordi_gagnant(pion, nlig, ncol);
        }
        break;

    case expert:
        coup_ordi_gagnant(pion, nlig, ncol);
        break;

    default:
        printf("Erreur : niveau non valide\n");
        break;
    }

    return *pion;
}

T_Case coup_joueur(T_Case *pion, int nlig, int ncol) {
    T_Tab_Case voisins;
    int choix = -1;

    // Obtenir toutes les cases voisines accessibles
    int nb_voisines = voisines(*pion, nlig, ncol, &voisins);

    if (nb_voisines == 0) {
        printf("Aucun déplacement possible depuis (%d, %d).\n", pion->ligne, pion->colonne);
        return *pion;
    }

    // Afficher les déplacements possibles
    printf("Votre pion est actuellement en (%d, %d)\n", pion->ligne, pion->colonne);
    printf("Coup(s) possible(s) :\n");
    for (int i = 0; i < nb_voisines; i++) {
        printf("  %d : (%d, %d)\n", i + 1, voisins.voisins[i].ligne, voisins.voisins[i].colonne);
    }

    // Demander à l'utilisateur de choisir un déplacement valide
    do {
        printf("Choisissez un coup (1-%d) : ", nb_voisines);
        if (scanf("%d", &choix) != 1) {
            printf("Entrée invalide. Veuillez entrer un numéro valide.\n");
            while (getchar() != '\n');
            choix = -1;
        } else if (choix < 1 || choix > nb_voisines) {
            printf("Choix hors des limites. Veuillez réessayer.\n");
        }
    } while (choix < 1 || choix > nb_voisines);

    // Appliquer le déplacement choisi
    *pion = voisins.voisins[choix - 1];

    return *pion;
}