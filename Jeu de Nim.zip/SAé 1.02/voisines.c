#include <stdio.h>
#include <stdlib.h>
#include "nim.h"
#include "voisines.h"

int voisines(T_Case pion, int nlig, int ncol, T_Tab_Case *vois) {
    vois->nb_vois = 0;

    // Ajout des voisines en bas (1 ou 2 cases)
    if (pion.ligne + 1 <= nlig) {
        vois->voisins[vois->nb_vois++] = (T_Case){pion.ligne + 1, pion.colonne};
    }
    if (pion.ligne + 2 <= nlig) {
        vois->voisins[vois->nb_vois++] = (T_Case){pion.ligne + 2, pion.colonne};
    }

    // Ajout des voisines à droite (1 ou 2 cases)
    if (pion.colonne + 1 <= ncol) {
        vois->voisins[vois->nb_vois++] = (T_Case){pion.ligne, pion.colonne + 1};
    }
    if (pion.colonne + 2 <= ncol) {
        vois->voisins[vois->nb_vois++] = (T_Case){pion.ligne, pion.colonne + 2};
    }
    return vois->nb_vois;
}