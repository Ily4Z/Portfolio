#ifndef PLATEAU_H
#define PLATEAU_H

#include "nim.h"
#include "parametres.h"

void afficher_plateau(T_Case pion, int nlig, int ncol);

#endif