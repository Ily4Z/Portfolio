#ifndef COUP_H
#define COUP_H

#include "nim.h"
#include "voisines.h"
#include "utilitaires.h"

T_Case coup_joueur(T_Case *pion, int nlig, int ncol);

T_Case coup_ordi(T_Case *pion, int nlig, int ncol, int niveau);

T_Case coup_ordi_hasard(T_Case *pion, T_Tab_Case *position, int nb_voisines, int nlig, int ncol);

T_Case coup_ordi_gagnant(T_Case *pion, int nlig, int ncol);


#endif