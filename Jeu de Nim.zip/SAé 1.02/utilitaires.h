#ifndef UTILITAIRES_H
#define UTILITAIRES_H

#include <stdlib.h>
#include "nim.h"

int hasard(int min, int max);

#endif

