#include <stdio.h>
#include <stdlib.h>
#include "nim.h"

// Calcule le nimber
int nimber(int ligne, int colonne, int nlig, int ncol) {

    int decalage = (nlig - ligne - 1) % 3;  
    int nim = (colonne - (ncol - 1) + decalage) % 3; 
    return (nim == 0) ? 0 : 1;  
}