#include <stdio.h>
#include "nim.h"
#include "affichage.h"
#include "voisines.h"
#include "coup.h"
#include "utilitaires.h"
#include "parametres.h"
#include "coup_joueur.h"

/*-------------------------- Test de la fonction nimber -------------------------*/

void test_nimber() {
    int nlig = 5;
    int ncol = 7;
    printf("\nTest Nimber: Affichage des nimbers pour un plateau %dx%d\n", nlig, ncol);
    for (int i = 0; i < nlig; i++) {
        for (int j = 0; j < ncol; j++) {
            T_Case case_test = {i, j};
            int nimber_value = nimber(case_test.ligne, case_test.colonne, nlig, ncol);
            printf("(%d, %d): %d\t", i, j, nimber_value);
        }
        printf("\n");
    }
}

/*-------------------------- Test de la fonction afficher_plateau -------------------------*/


void test_afficher_plateau(){
    T_Case pion = {3, 3};
    int nlig = 5;
    int ncol = 7;
    printf("\nTest Afficher plateau: Affichage du plateau %dx%d :\n\n", nlig, ncol);
    afficher_plateau(pion, nlig, ncol);
}


/*-------------------------- Test de la fonction hasard -------------------------*/

void test_hasard() {
    int val = hasard(1, 10);
    printf("\nTest Hasard: Valeur générée entre 1 et 10 -> %d\n", val);
}

/*-------------------------- Test de la fonction voisines -------------------------*/

void test_voisines() {
    T_Case pion = {3, 3};
    int nlig = 5, ncol = 5;
    T_Tab_Case position;

    int nb_vois = voisines(pion, nlig, ncol, &position);
    printf("\nTest Voisines: Case (%d, %d) a %d voisines :\n", pion.ligne, pion.colonne, nb_vois);
    for (int i = 0; i < nb_vois; i++) {
        printf("\nVoisine %d : (%d, %d)\n", i + 1, position.voisins[i].ligne, position.voisins[i].colonne);
    }
    printf("\n");
}

/*-------------------------- Test de la fonction coup_joueur -------------------------*/

void test_coup_joueur() {
    T_Case pion = {1, 1};
    int nlig = 5, ncol = 5;
    T_Tab_Case position;

    int nb_vois = voisines(pion, nlig, ncol, &position);
    printf("\nTest Coup Joueur: Coups possibles depuis (%d, %d) :\n", pion.ligne, pion.colonne);
    for (int i = 0; i < nb_vois; i++) {
        printf("\nOption %d : (%d, %d)\n", i + 1, position.voisins[i].ligne, position.voisins[i].colonne);
    }
    printf("\n");
}

/*-------------------------- Test de la fonction coup_ordi_hasard -------------------------*/

void test_coup_ordi_hasard() {
    T_Case pion = {1, 1};
    int nlig = 5, ncol = 5;
    T_Tab_Case position;

    int nb_voisines = voisines(pion, nlig, ncol, &position);

    if (nb_voisines > 0) {
        printf("\nAvant le coup de l'ordinateur: Pion en (%d, %d)\n\n", pion.ligne, pion.colonne);
        coup_ordi_hasard(&pion, &position, nb_voisines, nlig, ncol);
        printf("\nAprès le coup de l'ordinateur: Pion en (%d, %d)\n\n", pion.ligne, pion.colonne);
    } else {
        printf("\nErreur: Pas de voisins valides pour coup_ordi_hasard !\n");
    }
}

/*-------------------------- Test de la fonction coup_ordi_gagnant -------------------------*/

void test_coup_ordi_gagnant() {
    T_Case pion = {1, 2};
    int nlig = 5, ncol = 5;
    T_Tab_Case position;

    int nb_voisines = position.nb_vois;

    if (nb_voisines > 0) {
        printf("\nAvant le coup gagnant de l'ordinateur: Pion en (%d, %d)\n\n", pion.ligne, pion.colonne);
            coup_ordi_gagnant(&pion, nlig, ncol);
        printf("\nAprès le coup de l'ordinateur: Pion en (%d, %d)\n\n", pion.ligne, pion.colonne);
    } else {
        printf("\nErreur: Pas de voisins valides pour coup_ordi_gagnant !\n");
    }
}

/*-------------------------- Main de tests -------------------------*/

int main() {
    printf("\n=== Début des tests ===\n");

    test_nimber();
    test_afficher_plateau();
    test_hasard();
    test_voisines();
    test_coup_joueur();
    test_coup_ordi_hasard();
    test_coup_ordi_gagnant();

    printf("\n=== Fin des tests ===\n\n");
    return 0;
}
