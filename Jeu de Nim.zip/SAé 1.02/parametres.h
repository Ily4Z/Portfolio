#ifndef PARAMETRES_H
#define PARAMETRES_H

#include "nim.h"

void parametres(int *nlig, int *ncol, int *niveau, int *suivant);
int lire_entier(int min, int max);

#endif
