-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: devbdd.iutmetz.univ-lorraine.fr
-- Creato il: Gen 20, 2025 alle 22:56
-- Versione del server: 10.3.39-MariaDB
-- Versione PHP: 8.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e38800u_zooSAE104`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `alimentation`
--

CREATE TABLE `alimentation` (
  `id_alimentation` int(10) NOT NULL,
  `id_animaux` int(10) NOT NULL,
  `nom_alimentation` varchar(20) NOT NULL,
  `type_alimentation` varchar(20) NOT NULL,
  `frequence_distribution` int(5) NOT NULL,
  `quantite_distribution` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `alimentation`
--

INSERT INTO `alimentation` (`id_alimentation`, `id_animaux`, `nom_alimentation`, `type_alimentation`, `frequence_distribution`, `quantite_distribution`) VALUES
(1, 1, 'Bambou', 'Herbivore', 4, 25),
(2, 218, 'Viande', 'Carnivore', 1, 6),
(3, 7, 'Poisson', 'Carnivore', 4, 1),
(4, 62, 'Herbe', 'Herbivore', 4, 7),
(5, 26, 'Fruits', 'Frugivore', 1, 0.4);

-- --------------------------------------------------------

--
-- Struttura della tabella `animaux`
--

CREATE TABLE `animaux` (
  `id_animaux` int(10) NOT NULL,
  `id_enclos` int(10) NOT NULL,
  `nom_animaux` varchar(20) NOT NULL,
  `nom_scientifique` varchar(35) NOT NULL,
  `famille_animaux` varchar(35) NOT NULL,
  `nom_vulgaire` varchar(35) NOT NULL,
  `population_estimee` int(10) NOT NULL,
  `sexe` varchar(10) NOT NULL,
  `date_naissance` date NOT NULL,
  `date_arrivee` date NOT NULL,
  `effectif_espece` int(10) NOT NULL,
  `pays_animaux` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `animaux`
--

INSERT INTO `animaux` (`id_animaux`, `id_enclos`, `nom_animaux`, `nom_scientifique`, `famille_animaux`, `nom_vulgaire`, `population_estimee`, `sexe`, `date_naissance`, `date_arrivee`, `effectif_espece`, `pays_animaux`) VALUES
(1, 89, 'Albert', 'Ailuropoda melanoleuca', 'Ours', 'Panda', 1864, 'Male', '2016-12-19', '2017-12-22', 4, 'Chine'),
(7, 18, 'George', 'Aptenodytes patagonicus', 'Manchots', 'Manchot Royal', 1000000, 'Male', '2024-01-29', '2024-01-29', 18, 'Géorgie du Sud'),
(26, 47, 'Nicole', 'Aotus', 'Aotidae', 'Douroucouli', 350000, 'Femelle', '2022-10-25', '2023-11-16', 7, 'Brésil'),
(62, 146, 'Melly', 'Equus zebra', 'Équidés', 'Zèbre', 660000, 'Femelle', '2019-05-22', '2021-07-14', 13, 'Éthiopie'),
(218, 54, 'Simba', 'Panthera leo', 'Félins', 'Lion', 30000, 'Male', '2012-08-14', '2022-09-05', 9, 'Afrique');

-- --------------------------------------------------------

--
-- Struttura della tabella `enclos`
--

CREATE TABLE `enclos` (
  `id_enclos` int(10) NOT NULL,
  `id_zoo` int(10) NOT NULL,
  `type_enclos` varchar(15) NOT NULL,
  `loc_enclos` varchar(30) DEFAULT NULL,
  `superficie_enclos` float NOT NULL,
  `tot_enclos` int(5) NOT NULL,
  `capacite_enclos` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `enclos`
--

INSERT INTO `enclos` (`id_enclos`, `id_zoo`, `type_enclos`, `loc_enclos`, `superficie_enclos`, `tot_enclos`, `capacite_enclos`) VALUES
(18, 1, 'Iceberg', 'Animaux nord', 600, 3, 30),
(47, 1, 'Forêt tropicale', 'Animaux tropicaux', 500, 3, 25),
(54, 1, 'Savane', 'Animaux savane', 1000, 2, 10),
(89, 1, 'Forêt bambou', 'Grands animaux', 1100, 1, 5),
(146, 1, 'Savane', 'Animaux savane', 1000, 4, 10);

-- --------------------------------------------------------

--
-- Struttura della tabella `historique_animaux`
--

CREATE TABLE `historique_animaux` (
  `id_animaux` int(11) NOT NULL,
  `depart_animaux` varchar(50) NOT NULL,
  `cause_depart` varchar(200) DEFAULT NULL,
  `date_depart` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `historique_animaux`
--

INSERT INTO `historique_animaux` (`id_animaux`, `depart_animaux`, `cause_depart`, `date_depart`) VALUES
(1, 'Enclos A', 'Transfert vers un autre zoo', '2023-02-15'),
(218, 'Enclos C', 'Décès', '2022-11-03'),
(7, 'Enclos B', 'Libération dans la nature', '2024-12-01'),
(62, 'Enclos D', 'Transfert vers une autre zone', '2024-01-05'),
(26, 'Enclos E', 'Réhabilitation terminée', '2023-12-01');

-- --------------------------------------------------------

--
-- Struttura della tabella `responsable`
--

CREATE TABLE `responsable` (
  `id_resp` int(5) NOT NULL,
  `id_enclos` int(5) NOT NULL,
  `date_embauche` date NOT NULL,
  `nom_resp` varchar(30) NOT NULL,
  `prenom_resp` varchar(30) NOT NULL,
  `poste_resp` varchar(100) NOT NULL,
  `tel_resp` varchar(10) NOT NULL,
  `adresse_resp` varchar(50) NOT NULL,
  `salaire_resp` int(5) NOT NULL,
  `ville_resp` varchar(30) NOT NULL,
  `cp_resp` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `responsable`
--

INSERT INTO `responsable` (`id_resp`, `id_enclos`, `date_embauche`, `nom_resp`, `prenom_resp`, `poste_resp`, `tel_resp`, `adresse_resp`, `salaire_resp`, `ville_resp`, `cp_resp`) VALUES
(1, 89, '2020-05-15', 'Dupont', 'Jean', 'Responsable zoologique', '0612345678', '12 rue des Lions', 2800, 'Paris', '75015'),
(2, 54, '2018-03-10', 'Martin', 'Sophie', 'Soigneur en chef', '0623456789', '34 avenue des Tigres', 3200, 'Lyon', '69003'),
(3, 18, '2021-11-01', 'Durand', 'Paul', 'Responsable vétérinaire', '0634567890', '56 boulevard des Ours', 4000, 'Marseille', '13008'),
(4, 146, '2019-07-20', 'Bernard', 'Claire', 'Responsable des oiseaux', '0645678901', '78 rue des Aigles', 2900, 'Toulouse', '31000'),
(5, 47, '2022-01-25', 'Morel', 'Luc', 'Responsable des reptiles', '0656789012', '90 impasse des Serpents', 3100, 'Nice', '06000');

-- --------------------------------------------------------

--
-- Struttura della tabella `soin`
--

CREATE TABLE `soin` (
  `id_soin` int(10) NOT NULL,
  `id_veto` int(10) NOT NULL,
  `id_animaux` int(10) NOT NULL,
  `date_soin` date NOT NULL,
  `type_soin` varchar(50) NOT NULL,
  `etat_de_sante` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `soin`
--

INSERT INTO `soin` (`id_soin`, `id_veto`, `id_animaux`, `date_soin`, `type_soin`, `etat_de_sante`) VALUES
(1, 1, 1, '2023-07-10', 'Vaccination', 'Bonne'),
(2, 2, 218, '2023-08-15', 'Extraction dentaire', 'Satisfaisant'),
(3, 3, 7, '2023-09-05', 'Examen général', 'Excellent'),
(4, 4, 62, '2023-10-20', 'Soins postopératoires', 'En récupération'),
(5, 5, 26, '2023-11-30', 'Traitement antiparasitaire', 'Bonne');

-- --------------------------------------------------------

--
-- Struttura della tabella `stock`
--

CREATE TABLE `stock` (
  `id_stock` int(10) NOT NULL,
  `id_alimentation` int(10) NOT NULL,
  `type_produit` varchar(20) NOT NULL,
  `stock_dispo` int(15) NOT NULL,
  `date_reappro` date NOT NULL,
  `taux_remplacement` decimal(6,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `stock`
--

INSERT INTO `stock` (`id_stock`, `id_alimentation`, `type_produit`, `stock_dispo`, `date_reappro`, `taux_remplacement`) VALUES
(1, 101, 'Fruits', 200, '2024-01-15', 0),
(2, 102, 'Viandes', 50, '2024-01-10', 0),
(3, 103, 'Grains', 300, '2024-01-20', 0),
(4, 104, 'Poissons', 80, '2024-01-18', 0),
(5, 105, 'Légumes', 150, '2024-01-12', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `tarif_zoo`
--

CREATE TABLE `tarif_zoo` (
  `id_zoo` int(10) NOT NULL,
  `tarif_culturel` float NOT NULL,
  `tarif_enfant` float NOT NULL,
  `tarif_adultes` float NOT NULL,
  `tarif_etudiants` float NOT NULL,
  `tarif_famille` float NOT NULL,
  `tarif_senior` float NOT NULL,
  `tarif_handicapé` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `tarif_zoo`
--

INSERT INTO `tarif_zoo` (`id_zoo`, `tarif_culturel`, `tarif_enfant`, `tarif_adultes`, `tarif_etudiants`, `tarif_famille`, `tarif_senior`, `tarif_handicapé`) VALUES
(1, 7, 10, 15, 12, 7, 10, 12);

-- --------------------------------------------------------

--
-- Struttura della tabella `veterinaire`
--

CREATE TABLE `veterinaire` (
  `id_veto` int(10) NOT NULL,
  `id_animaux` int(10) NOT NULL,
  `nom_veto` varchar(20) NOT NULL,
  `prenom_veto` varchar(20) NOT NULL,
  `specialite` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `veterinaire`
--

INSERT INTO `veterinaire` (`id_veto`, `id_animaux`, `nom_veto`, `prenom_veto`, `specialite`) VALUES
(1, 1, 'Dupont', 'Jean', 'Chirurgie'),
(2, 218, 'Martin', 'Sophie', 'Soins dentaires'),
(3, 7, 'Durand', 'Paul', 'Pathologie animale'),
(4, 62, 'Bernard', 'Claire', 'Soins des grands mammifères'),
(5, 26, 'Morel', 'Luc', 'Soins des reptiles');

-- --------------------------------------------------------

--
-- Struttura della tabella `zoo`
--

CREATE TABLE `zoo` (
  `id_zoo` int(10) NOT NULL,
  `taux_entree_zoo` float NOT NULL,
  `nom_zoo` varchar(30) NOT NULL,
  `tel_zoo` varchar(10) NOT NULL,
  `mail_zoo` varchar(20) NOT NULL,
  `adresse_zoo` varchar(30) NOT NULL,
  `ville_zoo` varchar(20) NOT NULL,
  `cp_zoo` varchar(5) NOT NULL,
  `superficie` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dump dei dati per la tabella `zoo`
--

INSERT INTO `zoo` (`id_zoo`, `taux_entree_zoo`, `nom_zoo`, `tel_zoo`, `mail_zoo`, `adresse_zoo`, `ville_zoo`, `cp_zoo`, `superficie`) VALUES
(1, 300000, 'Pueblo Zoo', '0636872388', 'pueblo.zoo@gmail.com', '1 Rue du Tigre', 'Amneville', '57360', 600000);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `alimentation`
--
ALTER TABLE `alimentation`
  ADD PRIMARY KEY (`id_alimentation`),
  ADD KEY `id_animaux` (`id_animaux`);

--
-- Indici per le tabelle `animaux`
--
ALTER TABLE `animaux`
  ADD PRIMARY KEY (`id_animaux`),
  ADD KEY `id_enclos` (`id_enclos`);

--
-- Indici per le tabelle `enclos`
--
ALTER TABLE `enclos`
  ADD PRIMARY KEY (`id_enclos`),
  ADD KEY `id_zoo` (`id_zoo`);

--
-- Indici per le tabelle `historique_animaux`
--
ALTER TABLE `historique_animaux`
  ADD KEY `id_animaux` (`id_animaux`);

--
-- Indici per le tabelle `responsable`
--
ALTER TABLE `responsable`
  ADD PRIMARY KEY (`id_resp`),
  ADD KEY `id_enclos` (`id_enclos`);

--
-- Indici per le tabelle `soin`
--
ALTER TABLE `soin`
  ADD PRIMARY KEY (`id_soin`),
  ADD KEY `id_veto` (`id_veto`),
  ADD KEY `id_animaux` (`id_animaux`);

--
-- Indici per le tabelle `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id_stock`),
  ADD KEY `id_alimentation` (`id_alimentation`);

--
-- Indici per le tabelle `tarif_zoo`
--
ALTER TABLE `tarif_zoo`
  ADD KEY `id_zoo` (`id_zoo`);

--
-- Indici per le tabelle `veterinaire`
--
ALTER TABLE `veterinaire`
  ADD PRIMARY KEY (`id_veto`),
  ADD KEY `id_animaux` (`id_animaux`);

--
-- Indici per le tabelle `zoo`
--
ALTER TABLE `zoo`
  ADD PRIMARY KEY (`id_zoo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
